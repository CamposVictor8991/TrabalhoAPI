package org.serratec.trabalho.individual.funcionario.API.Trabalho.Repository;

import org.serratec.trabalho.individual.funcionario.API.Trabalho.Domain.Funcionario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FuncionarioRepository extends JpaRepository<Funcionario, Long> {

}
