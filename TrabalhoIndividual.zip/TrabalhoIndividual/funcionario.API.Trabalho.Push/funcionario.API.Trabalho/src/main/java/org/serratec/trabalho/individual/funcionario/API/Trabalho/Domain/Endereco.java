package org.serratec.trabalho.individual.funcionario.API.Trabalho.Domain;

import jakarta.persistence.Embeddable;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
@Embeddable
public class Endereco  {
	
	
	
	@NotBlank (message = "Este campo é obrigatório")
	@Size (max=50)
	public String rua;
	
	@NotBlank (message = "Este campo é obrigatório")
	@Size (max=50)
	public String cidade;
	
	@NotBlank (message = "Este campo é obrigatório")
	@Size (max=50)
	public String estado;
	
	@NotBlank (message = "Este campo é obrigatório")
	@Size (max=9)
	public String cep;
	
	
}
